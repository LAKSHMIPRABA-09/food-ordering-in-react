//firebase.js
const firebaseConfig = {
  apiKey: "AIzaSyBi_vRwQBQME9sk8vBifWX4nQK9s5mZrkk",
  authDomain: "red-onion-9ce35.firebaseapp.com",
  projectId: "red-onion-9ce35",
  storageBucket: "red-onion-9ce35.appspot.com",
  messagingSenderId: "981660706365",
  appId: "1:981660706365:web:074f0ac6191958c905ac54"
};

export default firebaseConfig